import time
from datetime import datetime
import torch
import torch.nn as nn
import os
import statistics

from parsers import parsersers_,constellation,snrdb_list_test
from Data_loader import Data_loader_test
from Train_Eval_funcs import evaluate

from GNN import GNN
from GAMPNet import GAMPNet

dtype = torch.float64
torch.set_default_dtype(dtype)

device = torch.device('cuda', index=0) if torch.cuda.is_available() else torch.device('cpu')
if torch.cuda.is_available():
    torch.cuda.set_device(0)
    
args=vars(parsersers_())


compare         = args['compare']
runHPC          = args['runHPC']

Nr              = args['Nr']
Nt_list_train   = args['Nt_list']
Nt_list         = args['Nt_list_test']
corr_coef       = args['corr']
CH_err          = args['CHerr']
num_classes     = args['num_classes']

total_samples   = args['samples']
bs_test         = args['bs_test']
iter_data       = round(total_samples/bs_test)

         
num_classes     = args['num_classes']

beta            = args['beta']
num_neuron      = args['num_neuron']
num_su          = args['su']
dropout         = args['Dropout']

iter_GAMP     = args['iter_GAMPNet']
iter_gnn        = args['iter_GNN']
iter_EP_gD      = args['iter_EP_genData']
QAM_cardinality = len(constellation)**2


dt_string = datetime.now().strftime("%d_%H:%M:%S")

GAMPNet = GAMPNet(iter_GAMP, beta, Nr,num_su, num_neuron,constellation, device, dtype)

model = GNN(iter_gnn, num_neuron, num_su, num_classes, dropout).to(device)
criterion = nn.CrossEntropyLoss().to(device)
name=GAMPNet.__class__.__name__ 


# if torch.cuda.device_count() > 1:
#     print("Let's use", torch.cuda.device_count(), "GPUs!")
#     # dim = 0 [30, xxx] -> [10, ...], [10, ...], [10, ...] on 3 GPUs
#     model = nn.DataParallel(model)

# model.to(device)



model.load_state_dict(torch.load(f'models/{name}_{Nr}X{Nt_list_train}_{QAM_cardinality}QAM/model.pkl'))
model=model.to(device)


model.eval()


for Nt in (Nt_list):
    test_SER_MMSE_list=[]
    test_SER_EP_list=[]
    test_SER_ML_list=[]
    test_SER_list=[]
    idxs=[]
    snr_list = snrdb_list_test[Nt]
    for snr in snr_list:
        
        t = time.time()
        
        S_MMSE_list = []
        S_EP_list = []
        S_ML_list = []
        S_GAMP_list = []
        variance_list = []

        for iter_data_index in range(iter_data):
        
            dataLoader= Data_loader_test (Nt, Nr, bs_test, snr, constellation, corr_coef, CH_err,iter_EP_gD,compare)
            test_dataloader,SER_mmse,SER_EP,SER_Max_likelihood = dataLoader.getTestData()  
            
            loss_val,val_acc,val_SER,val_variance = evaluate(model,GAMPNet,device,test_dataloader, criterion, Nt*2,dtype,constellation)
        # print(f'SNR={snr:.4f} \n')
            S_MMSE_list.append(SER_mmse)
            S_EP_list.append(SER_EP)
            S_ML_list.append(SER_Max_likelihood)
            S_GAMP_list.append(val_SER)
            variance_list.append(val_variance)
                    
        if compare: 
            p_mmse = statistics.mean(S_MMSE_list)   
            p_ep = statistics.mean(S_EP_list) 
            p_ml = statistics.mean(S_ML_list) 
            
            test_SER_MMSE_list.append(p_mmse)                                                                                                                                 
            test_SER_EP_list.append(p_ep)                                                                                                                                 
            test_SER_ML_list.append(p_ml)     

        p_gamp = statistics.mean(S_GAMP_list)
        variance = statistics.mean(variance_list)


        test_SER_list.append(p_gamp)
        Var_decouple.append(variance)
        
        idxs.append(snr)
        elapsed = time.time() - t
            
        if  runHPC ==False:
            if compare == True:
                print(f'SNR={snr}: SER_MMSE {p_mmse:.8f}; SER_EP {p_ep:.8f}; SER_Max_likelihood {p_ml:.8f}; SER_GAMPNet {p_gamp:.8f} \n')
            else:
                print(f'SNR={snr}: SER_GAMPNet {p_gamp:.8f} \n')
            print("Time elapsed" ,elapsed,"\n")
    
        

    if not os.path.exists(f'Test_reports/{name}_{Nr}X{Nt}_{QAM_cardinality}QAM'):
        os.makedirs(f'Test_reports/{name}_{Nr}X{Nt}_{QAM_cardinality}QAM')
    
    if compare: 
        report={'MMSE':test_SER_MMSE_list,'EP':test_SER_EP_list,'ML':test_SER_ML_list,'GAMPNet':test_SER_list}
        f = open(f'Test_reports/{name}_{Nr}X{Nt}_{QAM_cardinality}QAM/TestReport.txt',"w")
        f.write("SNR=" + str(idxs) + "\n" + "MMSE=" + str(test_SER_MMSE_list) + "\n" + "EP=" + str(test_SER_EP_list) + "\n" + "ML=" + str(test_SER_ML_list) + "\n" + "GAMPNet=" + str(test_SER_list))
        f.close()
    else:    
        report={'GAMPNet':test_SER_list}
        f = open(f'Test_reports/{name}_{Nr}X{Nt}_{QAM_cardinality}QAM/TestReport.txt',"w")
        f.write("SNR=" + str(idxs) + "\n"+ "GAMPNet=" + str(test_SER_list))
        f.write("SNR=" + str(idxs) + "\n"+ "GAMPNet=" + str(Var_decouple))
        f.close()
    
    
    f = open(f'Test_reports/{name}_{Nr}X{Nt}_{QAM_cardinality}QAM/NumberofTestingData.txt', "w")
    t_s = iter_data*bs_test
    f.write(str(t_s))
    f.close()
        
    if runHPC == False:
        from matplotlib import pyplot as plt
        if compare: 
            plt.semilogy(idxs,test_SER_EP_list,'bs-.', label='EP')
            plt.semilogy(idxs,test_SER_ML_list,'k-', label='ML')
            plt.semilogy(idxs,test_SER_MMSE_list,'r--', label='MMSE')
            plt.semilogy(idxs,test_SER_list,'go-.', label='GAMPNet')
        else:
            plt.semilogy(idxs,test_SER_list,'go-.', label='GAMPNet')
        # plt.title('A Simple Scatterplot')
        plt.xlabel('SNR (dB)')
        plt.ylabel('SER')
        plt.legend(loc='best')  
        plt.show()
        
            
        
