import argparse
import numpy as np

num_constell = 16
symblist = [x for x in range(1,17,2)] #max 26244-QAM
symPerQadrant = num_constell/4
list_of_symbols = [symblist[x] for x in range (int(np.sqrt(symPerQadrant)))]
energy_symbols = sum([number ** 2 for number in list_of_symbols])
    
norm_cons = np.sqrt(2*np.sqrt(symPerQadrant)  * ( energy_symbols) / symPerQadrant)
norm_symbs = list_of_symbols/norm_cons
constellation= np.array(np.concatenate((norm_symbs, -1*norm_symbs)), dtype=np.float32)
# TRAINING
NT1_tr = 64
# NT2_tr = 64
# snrdb_list_tr = {NT1_tr:np.array([16.0, 31.5]),NT2_tr:np.array([20.0, 41.5])}     # Only need to specify SNRdB min and max for training
snrdb_list_tr = {NT1_tr:np.array([20,20])}
# TESTING
NT1 = 64
# NT2=6
# NT3=8{
snrdb_list_test = {NT1:np.arange(0, 40, 2.5)}

# snrdb_list_test = {NT1:np.arange(16.0, 31.5,3.0),NT2:np.arange(18.0, 38.5,4.0),NT3:np.arange(20.0, 40.5,5.0)}


def parsersers_():
    parser = argparse.ArgumentParser(description='GNN for detection')
    
    parser.add_argument('--runHPC',default=False, help='run in HPC')
    parser.add_argument('--saved_all_models',default=False, help='saved_all_models')
    parser.add_argument('--genData', default=True, help='generate new data')
    parser.add_argument('--compare', default=False, help='compare with other detectors')
    
    parser.add_argument('--samples', type=int, default=100000, help='train sample data')
    parser.add_argument('--batch_size', type=int, default=20, help='num_samplesPer_batch')
    parser.add_argument('--validation_size','-vs', type=int, default=5000, help='validation_size')
    parser.add_argument('--bs_test', type=int, default=64, help='TestingBatchSize')
    parser.add_argument('--n_epochs','-ne', type=int, default=500, help='n_epochs')
    
    parser.add_argument('--Nr', type=int, default = 64, help='Nr')
    parser.add_argument('--CHerr', type=float, default = 0, help='CHerr')
    parser.add_argument('--corr', type=float, default = 0, help='corr')
    # parser.add_argument('--Nt_list', type=int, default=np.arange(int(NT/2),NT+1), help='Nt_list')
    parser.add_argument('--Nt_list', type=int, default=np.array([NT1_tr]), help='Nt_list')
    parser.add_argument('--Nt_list_test', type=int, default=np.array([NT1]), help='Nt_list_test')
    
    parser.add_argument('--num_neuron', type=int, default=64, help='num_neuron')
    parser.add_argument('--Dropout', type=float, default=0, help='dropout')
    parser.add_argument('--su','-su', type=int, default=8, help='num_feature_su')# su shouild be changed with the different modulation
    parser.add_argument('--beta', type=float, default=0.7, help='beta_E-P')
    parser.add_argument('--learning_rate', type=float, default=0.001, help='learning_rate')
        
    parser.add_argument('--num_classes', type=int, default=constellation.shape[0], help='num_classes')
    parser.add_argument('--iter_EP_genData', type=float, default=10, help='EP at gen data')
    parser.add_argument('--iter_GAMPNet', type=int, default= 10, help='iter_GAMPNet')
    parser.add_argument('--iter_GNN', type=int, default=2, help='iter_GNN')
    return parser.parse_args()
