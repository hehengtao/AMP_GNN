
import numpy as np
import torch
import torch.nn as nn
import pickle
from sklearn.model_selection import train_test_split
from Gen_dat import genData

'''data loader'''
from torch.utils.data import DataLoader
from torch.utils.data import Dataset

class CF_Dataset(Dataset):
    def __init__(self, x, edge, Tx, noise_info, H, Rx):
        self.x = x
        self.edge = edge
        self.Tx = Tx
        self.noise_info =noise_info
        self.H =H
        self.Rx =Rx
    
    def __len__(self):
        return len(self.x)

    def __getitem__(self, idx):
        return self.x[idx,:], self.edge[idx,:] , self.Tx[idx,:], self.noise_info[idx,:],  self.H[idx,:],  self.Rx[idx,:]
    

class Data_loader (object) :
    
    def __init__(self, Nt, Nr, batch_size, SNR_dB_min, SNR_dB_max, constellation,corr_coef,CH_err):
    
        dtype = torch.float64
        # test_sizes = 0.2

        params = {
            'constellation': constellation,
            'Nt': Nt,  
            'Nr': Nr,  
            'batch_size': batch_size,
            'SNR_dB_min': SNR_dB_min,
            'SNR_dB_max': SNR_dB_max,
            'iter_EP_gD': 0,
            'compare': False
            }
        # print(params)
        
        # if (generate_data):
        GD=genData(params)
        H_real, tX, rX, init_feats, edge_weight, noise_info, SER_mmse,SER_EP,SER_Max_likelihood = GD.dataTrain(corr_coef,CH_err)
            # with open(f'{samples/1000}k_Nt_{Nt}_Nr_{Nr}_SNR_{SNR_dB_min}_{SNR_dB_max}_corrCoef_{corr_coef}_chError_{CH_err}_data.pkl', 'wb') as f: 
            #     pickle.dump([H_real, tX, rX, init_feats, edge_weight, noise_info, SER_mmse], f)
            # f.close()
        # else:
        #     f = open(f'{samples/1000}k_Nt_{Nt}_Nr_{Nr}_SNR_{SNR_dB_min}_{SNR_dB_max}_corrCoef_{corr_coef}_chError_{CH_err}_data.pkl', 'rb')
        #     H_real, tX, rX, init_feats, edge_weight, noise_info, SER_mmse = pickle.load(f)  
        #     f.close()

        # (H_real_train,H_real_val,
        #  rX_train,rX_val,
        #  init_feats_train, init_feats_val, 
        #  edge_weight_train, edge_weight_val,
        #  tX_train, tX_val) = train_test_split(H_real,rX,init_feats,edge_weight,tX)
         
        
        H_train=torch.from_numpy(H_real).to(dtype)
        Rx_train=torch.from_numpy(rX).to(dtype)
        x_train=torch.from_numpy(init_feats).to(dtype)
        edge_train = torch.from_numpy(edge_weight).to(dtype)
        Tx_train = torch.from_numpy(tX).to(torch.int64) 
        
        train_dataset = CF_Dataset(x_train, edge_train, Tx_train, noise_info, H_train, Rx_train)
        self.train_data = DataLoader(train_dataset, batch_size=batch_size)
        
        # H_val=torch.from_numpy(H_real_val).to(dtype)
        # Rx_val=torch.from_numpy(rX_val).to(dtype)
        # x_val=torch.from_numpy(init_feats_val).to(dtype)
        # edge_val = torch.from_numpy(edge_weight_val).to(dtype)
        # Tx_val = torch.from_numpy(tX_val).to(torch.int64)
        
        # val_dataset = CF_Dataset(x_val, edge_val, Tx_val, noise_info, H_val, Rx_val)
        # self.val_data = DataLoader(val_dataset, batch_size=batch_size)
        

    def getTrainData(self):
        return self.train_data
    
    # def getValData(self):
    #     return self.val_data
    


class Data_loader_test (object) :
    
    def __init__(self, Nt, Nr, bs_test, SNR_dB_test, constellation,corr_coef,CH_err,iter_EP_gD=0,compare=False):
    
        dtype = torch.float64
        test_sizes = 1
        
        params = {
            'constellation': constellation,
            'batch_size':bs_test,
            'Nt': Nt,  # Number of transmit antennas
            'Nr': Nr,  # Number of transmit antennas
            'SNR_dB_min': SNR_dB_test,
            'SNR_dB_max': SNR_dB_test,
            'iter_EP_gD': iter_EP_gD,
            'compare': compare
            }
        GD=genData(params)
        H_real, tX, rX, init_feats, edge_weight, noise_info, SER_mmse,SER_EP,SER_Max_likelihood = GD.dataTrain(corr_coef,CH_err)
        self.SER_mmse = SER_mmse
        self.SER_EP = SER_EP
        self.SER_Max_likelihood = SER_Max_likelihood
        
        # print('Number of testing data: ',len(tX))
         
        x_test=torch.from_numpy(init_feats).to(dtype)
        Tx_test = torch.Tensor(tX).to(torch.int64)
        edge_weight_test=torch.from_numpy(edge_weight).to(dtype)
        H_test=torch.from_numpy(H_real).to(dtype)
        Rx_test=torch.from_numpy(rX).to(dtype)
        
        test_dataset =CF_Dataset(x_test,edge_weight_test,Tx_test,noise_info,H_test,Rx_test)

        self.test_data =DataLoader(test_dataset, batch_size=bs_test)

    
    def getTestData(self):
        return self.test_data,self.SER_mmse,self.SER_EP,self.SER_Max_likelihood