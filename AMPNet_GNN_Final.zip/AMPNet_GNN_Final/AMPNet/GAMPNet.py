import torch
import numpy as np
import torch.nn as nn

from AMP import AMP


class GAMPNet (object):
    def __init__(self, iter_GAMP, beta ,Nr , su, num_neuron,cons, device, dtype):  
        
        self.iter_GAMP = iter_GAMP
        self.beta = beta
        # self.hid_feats_size = su
        self.hid_neuron_size= num_neuron
        self.cons = torch.from_numpy(cons).to(dtype).to(device)
        self.device = device
        self.dtype = dtype
        # self.norm_factor = torch.sqrt(torch.tensor(2.0*Nt))
        
    def forward(self, model, H, y, sigma2, u_feats, edge):
        
        user_num = H.shape[2] 
        W = None
        V = None
        p_GNN = None
        read_gru=None
        gru = torch.zeros((u_feats.shape[0],user_num,self.hid_neuron_size)).to(self.dtype).to(self.device)

        
        av_mess = torch.zeros((u_feats.shape[0],user_num )).to(self.dtype).to(self.device)
        var_mess = torch.ones((u_feats.shape[0],user_num )).to(self.dtype).to(self.device)
        
        AMP_model = AMP(H, y, sigma2, user_num, self.cons,u_feats.shape[0],self.beta,av_mess,var_mess)
        
        for iteration in range(self.iter_GAMP):
            diag_lamda = torch.zeros((u_feats.shape[0],user_num,user_num)).to(self.dtype).to(self.device)
            #Perform EP
            W, V,R,S2 = AMP_model.performAMP( W,V,p_GNN, iteration,self.device)
            
            #Perform GNN
            p_GNN, read_gru,gru = model(read_gru,gru,u_feats,edge,sigma2, R, S2, iteration)
            # p_y_x_GNN_list.append(p_y_x_GNN)
        # p_y_x_GNN_list = torch.cat(p_y_x_GNN_list,0)

        return p_GNN
            
            