def get_idx_dicts(user_num):
    #slicing parameters
    temp_a=[]
    temp_b=[]
    dict_index_val = {}
    dict_val_index = {}
    dict_iv = {}
    dict_final = {}
    t=0
    
    # for z in range(user_num):
    #     for i in range(user_num):
    #         if  (i!=z):
    #             for j in range(user_num):
    #                 if  (i!=j and j!=z):
    #                     dict_iv[t] = str(j) + str(z)
    #                     t+=1
    #                     # if (t%(user_num-1)==0):
    #                     #     t+=1
                    
    # t=0
    for i in range(user_num):
        for j in range(user_num):
            if  i!=j:
                temp_a.append(i)
                temp_b.append(j)
                dict_final[len(temp_a)-1]=  str(j) + str(i)
                dict_index_val[len(temp_a)-1] = str(i) + str(j)
                dict_val_index[str(i) + str(j)] = len(temp_a)-1
                # dict_iv[t] = str(i) + str(j)
                # t+=user_num-1
    
    # arranged_dicts=list(dict_iv.values())
    # aranged_dicts_final = list(dict_final.values())
                
                
    # arranged_labels=[]
    # for item in (arranged_dicts):
    #     for p, (q, r) in enumerate (dict_index_val.items()):
    #         if (r==item):
    #             arranged_labels.append(dict_val_index[item])
                
    
    # arranged_final_labels=[]
    # for item in (aranged_dicts_final):
    #     for p, (q, r) in enumerate (dict_index_val.items()):
    #         if (r==item):
    #             arranged_final_labels.append(dict_val_index[item])
                
                
    return temp_a,temp_b
        