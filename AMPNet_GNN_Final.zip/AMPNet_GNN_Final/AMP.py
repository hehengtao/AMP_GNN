import numpy as np
import torch
import torch.nn as nn


class AMP (object):
    def __init__(self, H, y, sigma2, user_num, constellation,batch_size,damp_mes,av_mess,var_mess):   
        self.H = H
        self.Ht = H.transpose(2,1)
        self.y = y
        self.sigma2 = sigma2
        self.user_num = user_num
        self.batch_size = batch_size
        self.antenna_num= H.shape[1]
        self.constellation = constellation
        self.soft_max = nn.Softmax(dim=2)        
        self.constellation_expanded = constellation.tile(self.batch_size,1).unsqueeze(2)
        self.constellation_expanded_transpose = constellation.tile(self.batch_size,user_num,1)
        self.sqrH = pow(abs(H), 2)
        self.sqrHt = self.sqrH.transpose(2,1)
        self.damp_mes = damp_mes
        self.av_mess =  av_mess 
        self.var_mess =  var_mess 

    def calculate_mean_var(self,pyx):
        mean = torch.matmul(pyx, self.constellation_expanded)
        var = torch.square(torch.abs(self.constellation_expanded_transpose - mean))
        var = torch.mul(pyx, var) 
        var = torch.sum(var, axis=2)
        return torch.squeeze(mean), var
            

    # def LMMSE(self,diag_lamda, H, y, sigma2, lamda, gamma):
    #     HtH = torch.matmul(H.permute(0,2,1), H)
    #     Hty = torch.squeeze(torch.matmul(H.permute(0,2,1), torch.unsqueeze(y,2)))
    #     torch.einsum('ijj->ij',diag_lamda)[...] = lamda*sigma2
    #     var = (torch.linalg.inv(HtH + diag_lamda )) 
    #     mean = (Hty) + gamma* sigma2
    #     mean = torch.matmul(var,torch.unsqueeze(mean,2))
    #     var = var* torch.unsqueeze(sigma2,2)
    #     del diag_lamda
    #     del HtH
    #     del Hty
    #     return mean, var

    def performAMP(self, W,V,p_y_x_GNN,  iter_num,device):
    
        if (iter_num == 0):
            W = torch.zeros((self.batch_size,self.antenna_num)).to(device)
            V = torch.ones((self.batch_size,self.antenna_num )).to(device)
            av_mess = self.av_mess
            var_mess = self.var_mess 
        else:
            # Calculating mean and variance of \hat{P}_x_y
            p_y_x_GNN = self.soft_max(p_y_x_GNN)
            av_mess, var_mess = self.calculate_mean_var(p_y_x_GNN)
            var_mess = torch.clamp(var_mess, 1e-13, None)
            
        # EXTRINSIC
        V_new =  torch.squeeze(torch.matmul(self.sqrH, torch.unsqueeze(var_mess,2)))
        W_new =  torch.squeeze(torch.matmul(self.H, torch.unsqueeze(av_mess,2))) - torch.divide(self.y - W, self.sigma2  + V) *V_new
        # damping
        W_new = self.damp_mes*W_new + (1-self.damp_mes)*W;            
        V_new = self.damp_mes*V_new + (1-self.damp_mes)*V;
        #
        inv_V = 1 / (self.sigma2 + V_new) ;
        var_1 = torch.squeeze(torch.matmul(self.sqrHt, torch.unsqueeze(inv_V,2)))
        var_2 = torch.squeeze(torch.matmul(self.Ht,  torch.unsqueeze(((self.y - W_new)*inv_V),2) ) )
        # VAR CAV MU CAV
        S2 = 1 / var_1;
        R = av_mess + S2 * var_2 ;
        V = V_new;
        W = W_new;
            

        return  W, V,R,S2